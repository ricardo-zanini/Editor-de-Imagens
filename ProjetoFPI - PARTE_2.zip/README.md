## Editor de Imagens - Fundamentos de Processamento de Imagens

# Projetado em Java utilizando a biblioteca "Swing"

- Inverte Imagens
- Aplicação de Filtro Cinza
- Quantização de Imagens

