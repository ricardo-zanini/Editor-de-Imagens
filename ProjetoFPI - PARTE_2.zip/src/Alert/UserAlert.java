package Alert;
import static javax.swing.JOptionPane.showMessageDialog;

public class UserAlert{
    public UserAlert(String message){
        showMessageDialog(null, message);
    }
}
